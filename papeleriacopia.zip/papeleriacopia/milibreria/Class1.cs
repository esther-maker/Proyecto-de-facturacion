﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace milibreria
{
    public class utilidades
    {
        public static DataSet ejecutar(string cmd)
        {
            SqlConnection SQL = new SqlConnection("SERVER=DESKTOP-RNRG215\\SQLEXPRESS;DATABASE=papeleria;INTEGRATED SECURITY=TRUE");
            SQL.Open();
            DataSet DT = new DataSet();
            SqlDataAdapter mt = new SqlDataAdapter(cmd, SQL);
            mt.Fill(DT);
            SQL.Close();
            return DT;

        }

       
       

     
        //   public static Boolean validarform(Control objeto, ErrorProvider Errorprovider)
        //  {
        //    Boolean hay = false;
        //   foreach (Control intem in objeto.Controls)
        //  {
        //     if (intem is Errortxtbox)
        //   {
        //     Errortxtbox obj = (Errortxtbox)intem;
        //   if (obj.validar == false)
        //  {
        //    if (string.IsNullOrEmpty(obj.Text.Trim()))
        //  {
        //    Errorprovider.SetError(obj, "no puede estar vacio pendjo");
        //     }
        //   else
        // {
        //   Errorprovider.SetError(obj, "");
        //}
        //}
        // }
        //return hay;
        //}
    }
    }



