﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class cuentcobrar2 : Form
    {
        public List<Datos> Datos = new List<Datos>();
        public cuentcobrar2()
        {
      
            InitializeComponent();
        }

        private void cuentcobrar2_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }
    }
}
