﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class facturaesp : Form
    {
        public facturaesp()
        {
            InitializeComponent();
        }

        private void facturageneral_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'basededatos.factura2' Puede moverla o quitarla según sea necesario.
            this.factura2TableAdapter.Fill(this.basededatos.factura2);

            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
