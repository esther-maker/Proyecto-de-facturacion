﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    
    
    public partial class agregarempl : Form
    {
        private PictureBox pictureBox1;
        private Label label1;
        private TextBox codigo;
        private TextBox direccion;
        private TextBox edad;
        private TextBox apellido;
        private TextBox nombre;
        private TextBox correo;
      // private IContainer components;
        private ComboBox comboBox1;
        private TextBox salario;
        private Button button1;
        private GroupBox groupBox2;
        private Button button6;
        private Button button8;
        private Button button9;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private MaskedTextBox telefono;
        private Button button2;
        private Label label2;
        private TextBox textBox1;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private MaskedTextBox cedula;
        private Label label3;
        private DataGridView dataGridView1;

        public agregarempl()
        {
            InitializeComponent();
        }
        conexion InstanciaBD = new conexion();
        bool Editar = false;


        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(agregarempl));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.codigo = new System.Windows.Forms.TextBox();
            this.direccion = new System.Windows.Forms.TextBox();
            this.edad = new System.Windows.Forms.TextBox();
            this.apellido = new System.Windows.Forms.TextBox();
            this.nombre = new System.Windows.Forms.TextBox();
            this.correo = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.salario = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.telefono = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cedula = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 286);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(793, 222);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(270, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 72);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(371, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(297, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "Agregar empleados";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // codigo
            // 
            this.codigo.BackColor = System.Drawing.Color.Gainsboro;
            this.codigo.Cursor = System.Windows.Forms.Cursors.No;
            this.codigo.Location = new System.Drawing.Point(128, 96);
            this.codigo.Name = "codigo";
            this.codigo.ReadOnly = true;
            this.codigo.Size = new System.Drawing.Size(100, 20);
            this.codigo.TabIndex = 17;
            this.codigo.Enter += new System.EventHandler(this.codigo_Enter);
            this.codigo.Leave += new System.EventHandler(this.codigo_Leave);
            // 
            // direccion
            // 
            this.direccion.Location = new System.Drawing.Point(314, 125);
            this.direccion.Name = "direccion";
            this.direccion.Size = new System.Drawing.Size(100, 20);
            this.direccion.TabIndex = 23;
            this.direccion.TextChanged += new System.EventHandler(this.direccion_TextChanged);
            this.direccion.Enter += new System.EventHandler(this.direccion_Enter);
            this.direccion.Leave += new System.EventHandler(this.direccion_Leave);
            // 
            // edad
            // 
            this.edad.Location = new System.Drawing.Point(128, 200);
            this.edad.Name = "edad";
            this.edad.Size = new System.Drawing.Size(100, 20);
            this.edad.TabIndex = 26;
            this.edad.TextChanged += new System.EventHandler(this.edad_TextChanged);
            this.edad.Enter += new System.EventHandler(this.edad_Enter);
            this.edad.Leave += new System.EventHandler(this.edad_Leave);
            // 
            // apellido
            // 
            this.apellido.Location = new System.Drawing.Point(128, 148);
            this.apellido.Name = "apellido";
            this.apellido.Size = new System.Drawing.Size(100, 20);
            this.apellido.TabIndex = 28;
            this.apellido.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            this.apellido.Enter += new System.EventHandler(this.apellido_Enter);
            this.apellido.Leave += new System.EventHandler(this.apellido_Leave);
            // 
            // nombre
            // 
            this.nombre.Location = new System.Drawing.Point(128, 122);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(100, 20);
            this.nombre.TabIndex = 29;
            this.nombre.Enter += new System.EventHandler(this.nombre_Enter);
            this.nombre.Leave += new System.EventHandler(this.nombre_Leave);
            // 
            // correo
            // 
            this.correo.Location = new System.Drawing.Point(314, 99);
            this.correo.Name = "correo";
            this.correo.Size = new System.Drawing.Size(100, 20);
            this.correo.TabIndex = 36;
            this.correo.Enter += new System.EventHandler(this.correo_Enter);
            this.correo.Leave += new System.EventHandler(this.correo_Leave);
            // 
            // comboBox1
            // 
            this.comboBox1.DisplayMember = "empleados.genero";
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "M",
            "H"});
            this.comboBox1.Location = new System.Drawing.Point(314, 151);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 40;
            this.comboBox1.ValueMember = "empleados.genero";
            // 
            // salario
            // 
            this.salario.Location = new System.Drawing.Point(314, 177);
            this.salario.Name = "salario";
            this.salario.Size = new System.Drawing.Size(100, 20);
            this.salario.TabIndex = 46;
            this.salario.Enter += new System.EventHandler(this.salario_Enter);
            this.salario.Leave += new System.EventHandler(this.salario_Leave);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(581, 61);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 37);
            this.button1.TabIndex = 49;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightBlue;
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.button9);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(509, 104);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(158, 176);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Opciones";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Honeydew;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(18, 131);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 31);
            this.button2.TabIndex = 46;
            this.button2.Text = "Deshabilitados";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Salmon;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(31, 94);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(89, 31);
            this.button6.TabIndex = 45;
            this.button6.Text = "Reporte";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Violet;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Microsoft YaHei", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.Location = new System.Drawing.Point(31, 20);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(89, 31);
            this.button8.TabIndex = 0;
            this.button8.Text = "Guardar";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Pink;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Microsoft YaHei", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(31, 57);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(89, 31);
            this.button9.TabIndex = 0;
            this.button9.Text = "Eliminar";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 50;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(509, 61);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(48, 37);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 51;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // telefono
            // 
            this.telefono.Location = new System.Drawing.Point(128, 226);
            this.telefono.Mask = "000-000-0000";
            this.telefono.Name = "telefono";
            this.telefono.Size = new System.Drawing.Size(100, 20);
            this.telefono.TabIndex = 52;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(87, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 53;
            this.label2.Text = "Código";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox1.Location = new System.Drawing.Point(128, 70);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 54;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 56;
            this.label4.Text = "Nombre";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(78, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 57;
            this.label5.Text = "Apellido";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(87, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 58;
            this.label6.Text = "Cédula";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(87, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 59;
            this.label7.Text = "Edad";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(73, 229);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 60;
            this.label8.Text = "Teléfono";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(267, 102);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 61;
            this.label9.Text = "Correo";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(261, 128);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 62;
            this.label10.Text = "Dirección";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(267, 154);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 13);
            this.label11.TabIndex = 63;
            this.label11.Text = "Género";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(267, 180);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 13);
            this.label12.TabIndex = 64;
            this.label12.Text = "Sueldo";
            // 
            // cedula
            // 
            this.cedula.Location = new System.Drawing.Point(128, 174);
            this.cedula.Mask = "000-0000000-0";
            this.cedula.Name = "cedula";
            this.cedula.Size = new System.Drawing.Size(100, 20);
            this.cedula.TabIndex = 65;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 66;
            this.label3.Text = "Buscar por nombre";
            // 
            // agregarempl
            // 
            this.BackgroundImage = global::papeleria2.Properties.Resources.e3ddce;
            this.ClientSize = new System.Drawing.Size(816, 533);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cedula);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.telefono);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.salario);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.correo);
            this.Controls.Add(this.nombre);
            this.Controls.Add(this.apellido);
            this.Controls.Add(this.edad);
            this.Controls.Add(this.direccion);
            this.Controls.Add(this.codigo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "agregarempl";
            this.Load += new System.EventHandler(this.agregarempl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void basededatosBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
     
        }

        private void ListarGenero()
        {
        }

        private void agregarempl_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = InstanciaBD.Datosempleadosactivos();
        




        }

        private void genero_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                Editar = true;
                codigo.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                nombre.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                apellido.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                cedula.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                edad.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                comboBox1.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                telefono.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                correo.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                direccion.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
               salario.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();

            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }

        }

        private void button4_Click(object sender, EventArgs e)
        { 

          
            }


    private void direccion_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        



        }

        private void cedula_Enter(object sender, EventArgs e)
        {
           if( cedula.Text == "Cédula")
            cedula.Text = "";
        }

        private void cedula_Leave(object sender, EventArgs e)
        {
            if(cedula.Text == "")
            cedula.Text = "Cédula";
            
        }

        private void codigo_Enter(object sender, EventArgs e)
        {
            
               if( codigo.Text == "Codigo empleado")
                codigo.Text = "";
            
        }
        private void codigo_Leave(object sender, EventArgs e)
        {
           if (codigo.Text == "")
            codigo.Text = "Codigo empleado";
        }

     
        private void nombre_Enter(object sender, EventArgs e)
        {
          if(nombre.Text == "Nombre")
            nombre.Text = "";

        }

        private void nombre_Leave(object sender, EventArgs e)
        {
           if( nombre.Text == "")
            nombre.Text = "Nombre";

        }

        private void apellido_Enter(object sender, EventArgs e)
        {
            if (apellido.Text == "Apellido")
                apellido.Text = "";
        }

        private void apellido_Leave(object sender, EventArgs e)
        {
            if (apellido.Text == "")
                apellido.Text = "Apellido";
        }

        private void edad_Enter(object sender, EventArgs e)
        {
            if (edad.Text == "Edad")
                edad.Text = "";
        }

        private void edad_Leave(object sender, EventArgs e)
        {
            if (edad.Text == "")
                edad.Text = "Edad";
        }

        private void telefono_Enter(object sender, EventArgs e)
        {
            if (telefono.Text == "Teléfono")
                telefono.Text = "";
        }

        private void telefono_Leave(object sender, EventArgs e)
        {
            if (telefono.Text == "")
                telefono.Text = "Teléfono";
        }

        private void correo_Enter(object sender, EventArgs e)
        {
            if (correo.Text == "Correo Electrónico")
                correo.Text = "";
        }

        private void correo_Leave(object sender, EventArgs e)
        {
            if (correo.Text == "")
                correo.Text = "Correo Electrónico";
        }

        private void direccion_Enter(object sender, EventArgs e)
        {
            if (direccion.Text == "Dirección")
                direccion.Text = "";
        }

        private void direccion_Leave(object sender, EventArgs e)
        {
            if (direccion.Text == "")
                direccion.Text = "Dirección";
        }

        private void salario_Enter(object sender, EventArgs e)
        {
            if (salario.Text == "Salario")
                salario.Text = "";
        }

        private void salario_Leave(object sender, EventArgs e)
        {
            if (salario.Text == "")
                salario.Text = "Salario";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                Editar = true;
                codigo.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                nombre.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                apellido.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                cedula.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                edad.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                telefono.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                correo.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                direccion.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                comboBox1.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
                salario.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();

            }

            else
            {
                MessageBox.Show("Seleccione una fila para utilizar Toolselection");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {

            if (Editar == false)
            {
                if (nombre.Text == "" || apellido.Text == "" ||  cedula.Text == "" || edad.Text == "" || telefono.Text == "" || correo.Text == "" || direccion.Text == "" || salario.Text == "")
                {
                    MessageBox.Show("Llene los campos");
                }
                else
                {
                    InstanciaBD.insertarempleados(nombre.Text, apellido.Text, cedula.Text, edad.Text, telefono.Text, correo.Text, direccion.Text, comboBox1.Text.ToString(), salario.Text, codigo.Text);
                    MessageBox.Show("Insertado correctamente");
                    dataGridView1.DataSource = InstanciaBD.Datosempleadosactivos();
                }

            }

            else if (Editar == true)
            {
                InstanciaBD.actualizarempleados(nombre.Text, apellido.Text, cedula.Text, edad.Text, telefono.Text, correo.Text, direccion.Text, comboBox1.Text.ToString(), salario.Text);
                MessageBox.Show("Actualizado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datosempleadosactivos();
                Editar = false;
            }
            else
            {
                MessageBox.Show("Usa Toolselection");
            }




















            {
                
                Editar = false;
                codigo.Clear();
                apellido.Clear();
                cedula.Clear();
                edad.Clear();
                correo.Clear();
                direccion.Clear();
                telefono.Clear();
                salario.Clear();

            }

        }

        private void button7_Click(object sender, EventArgs e)
        {


       
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                InstanciaBD.Eliminarempleados(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Registro elminado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datosempleadosactivos();

            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }
        }

        private void edad_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea limpiar los campos?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                codigo.Clear();
                nombre.Clear();
                apellido.Clear();
                cedula.Clear();
                edad.Clear();
                telefono.Clear();
                correo.Clear();
                direccion.Clear();
                salario.Clear();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            deshabilitdosempl jj = new deshabilitdosempl();
            jj.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                dataGridView1.DataSource = InstanciaBD.buscar(textBox1.Text);
            }
            else
            {
                dataGridView1.DataSource = InstanciaBD.Datosempleadosactivos();
            }

        }
    }
}
