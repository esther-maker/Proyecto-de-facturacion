﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace papeleria2
{
    class rhtml
    {
        conexion jj = new conexion();

        public void Insertarmonto(string fecha,string monto_pagar, string cod_clit)
        {
            jj.insertarcuenta(Convert.ToDateTime(fecha), Convert.ToDouble(monto_pagar), Convert.ToInt32(cod_clit));
        }
        public void guardarFact(string Cod_empleado, string cod_cliente, string fecha, string id_cuenta)
        {
            jj.guardarFact(Convert.ToInt32(Cod_empleado), Convert.ToInt32(cod_cliente), Convert.ToDateTime(fecha) , Convert.ToInt32(id_cuenta));
        }
        public void guardardetalle(string cod_fact, string Cod_producto, string cantidad, string precio, string preciototal, string monto, string devuelta)
        {
            jj.guardarDetalle(Convert.ToInt32(cod_fact), Convert.ToInt32(Cod_producto), Convert.ToInt32(cantidad), Convert.ToDouble(precio), Convert.ToDouble(preciototal), Convert.ToDouble(monto), Convert.ToDouble(devuelta));
        }
    }
}
