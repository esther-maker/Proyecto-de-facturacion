﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class clientes : Form
    {
        public clientes()
        {
            InitializeComponent();
        }

        private void prueb_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'BD.clientes' Puede moverla o quitarla según sea necesario.
            this.clientesTableAdapter.Fill(this.BD.clientes);
            // TODO: esta línea de código carga datos en la tabla 'basededatos.clientes' Puede moverla o quitarla según sea necesario.
            // this.clientesTableAdapter.Fill(this.basededatos.clientes);

            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {
         

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
