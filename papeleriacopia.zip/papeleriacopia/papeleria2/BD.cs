﻿namespace papeleria2
{


    partial class BD
    {
        partial class clientescopDataTable
        {


            partial class CompraDataTable
            {
            }
        }
    }
}
namespace papeleria2.BDTableAdapters
{
    partial class datosfactura1TableAdapter
    {
    }

    public partial class CompraTableAdapter {
    }
}
