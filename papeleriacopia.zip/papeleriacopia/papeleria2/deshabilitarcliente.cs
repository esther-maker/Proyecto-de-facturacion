﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class deshabilitarcliente : Form
    {
        public deshabilitarcliente()
        {
            InitializeComponent();
        }
        conexion InstanciaBD = new conexion();

        private void deshabilitarcliente_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = InstanciaBD.Datosclientes2();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count < 0)
            {
                MessageBox.Show("Seleccione una fila");
            }
            else
            {
                InstanciaBD.Eliminarclientes2(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Ha agregado un cliente eliminado");
                dataGridView1.DataSource = InstanciaBD.Datosclientes2();
            }
        }
    }
}
