﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class clientesssss : Form
    {
        public clientesssss()
        {
            InitializeComponent();
        }
        conexion InstanciaBD = new conexion();
        private void clientesssss_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = InstanciaBD.Datosclie();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                dataGridView1.DataSource = InstanciaBD.buscarcliente(textBox1.Text);
            }
            else
            {
                dataGridView1.DataSource = InstanciaBD.Datosclientes3();
            }
        }
    }
}
