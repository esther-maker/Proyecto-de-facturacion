﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class agregarprod : Form
    {
        public agregarprod()
        {
            InitializeComponent();
            this.mensaje.SetToolTip(this.button3, "Limpiar campos");
            this.mensaje.SetToolTip(this.button4, "Seleccionar filas");
            this.mensaje.SetToolTip(this.pictureBox2, "Atrás");
        }


        conexion InstanciaBD = new conexion();
        principal p = new principal();
        bool Editar = false;
       

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ListarMarcas()
        {
            comboBox1.DataSource = InstanciaBD.ListarMarcas();
            comboBox1.DisplayMember = "marca";
            comboBox1.ValueMember = "codigo_marca";
        }
        private void ListarProveedor()
        {
            proveedor.DataSource = InstanciaBD.ListProveedor();
            proveedor.DisplayMember = "nombre";
            proveedor.ValueMember = "id_prov";

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

       
        public void vee(object bb)
        {
            if (this.p.panel2.Controls.Count > 0)
                this.p.panel2.Controls.RemoveAt(0);
            Form mostrar = bb as Form;
            mostrar.TopLevel = false;
            mostrar.Dock = DockStyle.Fill;
            this.p.panel2.Controls.Add(mostrar);
            this.p.panel2.Tag = mostrar;
            mostrar.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            agregarproveedor proveedor = new agregarproveedor();
            proveedor.Show();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            agregarmarca prove = new agregarmarca();
            prove.Show();


        }

        private void button7_Click(object sender, EventArgs e)
        { 
            if (Editar == false)
            {
                if (Nombre.Text == "" || precio.Text == "" )
                {
                    MessageBox.Show("Llene los campos");
                }
                else
                {
                    InstanciaBD.insertarproductos(Nombre.Text, textBox3.Text, comboBox1.SelectedValue.ToString(), precio.Text, proveedor.SelectedValue.ToString());
                    MessageBox.Show("Insertado correctamente");
                    dataGridView1.DataSource = InstanciaBD.DatosProductos();
                    comboBox1.Refresh();
                }
                
            }
            
           else if (Editar== true)
            {
                InstanciaBD.actualizarproductos(Nombre.Text, textBox3.Text, comboBox1.SelectedValue.ToString(), precio.Text,proveedor.SelectedValue.ToString(), textBox2.Text);
               MessageBox.Show("Actualizado correctamente");
               dataGridView1.DataSource = InstanciaBD.DatosProductos();
                Editar = false;
           }
            else
            {
               MessageBox.Show("Usa Toolselection");
           }

        }

        private void productosBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

      
        private void agregarprod_Load(object sender, EventArgs e)
        {
            ListarMarcas();
            ListarProveedor();
            // TODO: esta línea de código carga datos en la tabla 'basededatos.proveedores' Puede moverla o quitarla según sea necesario.
            // this.proveedoresTableAdapter.Fill(this.basededatos.proveedores);
            // TODO: esta línea de código carga datos en la tabla 'basededatos.marca' Puede moverla o quitarla según sea necesario.
            //this.marcaTableAdapter.Fill(this.basededatos.marca);
            // TODO: esta línea de código carga datos en la tabla 'basededatos.produto_marca_prov' Puede moverla o quitarla según sea necesario.
            dataGridView1.DataSource = InstanciaBD.DatosProductos();
            dataGridView1.Refresh();
          
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                MessageBox.Show("Registro elminado");
                InstanciaBD.Eliminar(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                dataGridView1.DataSource = InstanciaBD.DatosProductos();

            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }



        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button9_Click(object sender, EventArgs e)
        {
        
           

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
   
            

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
        }
       

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
           
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                Editar = true;
                textBox2.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                Nombre.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                comboBox1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                precio.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                proveedor.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();

            }

            else
            {
                MessageBox.Show("Seleccione una fila para utilizar Toolselection");
            }
        }

        private void textBox2_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void proveedor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Cantidad_TextChanged(object sender, EventArgs e)
        {

        }

        private void precio_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
                if (textBox1.Text != "")
                {
                    dataGridView1.DataSource = InstanciaBD.buscarproductos(textBox1.Text);
                }
                else
                {
                    dataGridView1.DataSource = InstanciaBD.DatosProductos();
                }

            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            productos bie = new productos();
            bie.Show();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click_2(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                MessageBox.Show("Registro elminado");
                InstanciaBD.Eliminar(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                dataGridView1.DataSource = InstanciaBD.DatosProductos();
            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }
        }

        private void button3_Click_3(object sender, EventArgs e)
        {
           
        }

        private void Nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255 ))
            {
                MessageBox.Show("Ingresaste un número!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }

        private void precio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Ingresaste una letra!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("Ingresaste un número!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }

        private void button3_Click_4(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea limpiar los campos?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                textBox1.Clear();
                textBox2.Clear();

                Nombre.Clear();
                precio.Clear();
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Ingresaste una letra!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }
    }
    }
    

