﻿namespace papeleria2
{
    partial class pasar1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.codigoprod = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.precioprod = new System.Windows.Forms.TextBox();
            this.cantidadprod = new System.Windows.Forms.TextBox();
            this.nombreprod = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.dataGridView4);
            this.groupBox1.Controls.Add(this.codigoprod);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.precioprod);
            this.groupBox1.Controls.Add(this.cantidadprod);
            this.groupBox1.Controls.Add(this.nombreprod);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Location = new System.Drawing.Point(31, 34);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(389, 292);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos productos";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(87, 79);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 13);
            this.label17.TabIndex = 66;
            this.label17.Text = "Marca";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(153, 76);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(132, 20);
            this.textBox2.TabIndex = 65;
            // 
            // dataGridView4
            // 
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(24, 169);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(332, 107);
            this.dataGridView4.TabIndex = 64;
            // 
            // codigoprod
            // 
            this.codigoprod.Location = new System.Drawing.Point(153, 15);
            this.codigoprod.Margin = new System.Windows.Forms.Padding(4);
            this.codigoprod.Name = "codigoprod";
            this.codigoprod.Size = new System.Drawing.Size(132, 20);
            this.codigoprod.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 18);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 13);
            this.label8.TabIndex = 38;
            this.label8.Text = "Codigo producto";
            // 
            // precioprod
            // 
            this.precioprod.Location = new System.Drawing.Point(153, 107);
            this.precioprod.Margin = new System.Windows.Forms.Padding(4);
            this.precioprod.Name = "precioprod";
            this.precioprod.Size = new System.Drawing.Size(132, 20);
            this.precioprod.TabIndex = 37;
            // 
            // cantidadprod
            // 
            this.cantidadprod.Location = new System.Drawing.Point(153, 138);
            this.cantidadprod.Margin = new System.Windows.Forms.Padding(4);
            this.cantidadprod.Name = "cantidadprod";
            this.cantidadprod.Size = new System.Drawing.Size(132, 20);
            this.cantidadprod.TabIndex = 36;
            // 
            // nombreprod
            // 
            this.nombreprod.Location = new System.Drawing.Point(153, 45);
            this.nombreprod.Margin = new System.Windows.Forms.Padding(4);
            this.nombreprod.Name = "nombreprod";
            this.nombreprod.Size = new System.Drawing.Size(132, 20);
            this.nombreprod.TabIndex = 35;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(50, 110);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "Precio unidad";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(71, 135);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 33;
            this.label11.Text = "Cantidad";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(77, 48);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "Nombre";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(292, 130);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 67;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pasar1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 361);
            this.Controls.Add(this.groupBox1);
            this.Name = "pasar1";
            this.Text = "pasar1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label17;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.DataGridView dataGridView4;
        public System.Windows.Forms.TextBox codigoprod;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox precioprod;
        public System.Windows.Forms.TextBox cantidadprod;
        public System.Windows.Forms.TextBox nombreprod;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button1;
    }
}