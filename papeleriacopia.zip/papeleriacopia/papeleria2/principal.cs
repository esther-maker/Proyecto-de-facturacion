﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class principal : Form
    {
        public principal()
        {
            InitializeComponent();
        }


        public void vee(object bb)
        {
            if (this.panel2.Controls.Count > 0)
                this.panel2.Controls.RemoveAt(0);
            Form mostrar = bb as Form;
            mostrar.TopLevel = false;
            mostrar.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(mostrar);
            this.panel2.Tag = mostrar;
            mostrar.Show();
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }



        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }





        private void Form3_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void verOAgregarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void nuevaFacturaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void productoToolStripMenuItem_Click(object sender, EventArgs e)
        {
       
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void deudasToolStripMenuItem_Click(object sender, EventArgs e)
        {




        }


        private void button12_Click(object sender, EventArgs e)
        {

        }



        private void facturaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void empleadosToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void uentasPorCobrarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void comprasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ventasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void proveedoresToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void metodosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void facturaasAnterioresToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }



        private void filtrarDatosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ayudaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void productosToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void clientesToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void clientesToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void empleadosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void compraToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void cuentasPorCobrarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void proveedorToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void facturaAnterioresToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void empleadosToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void marcaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void omprasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void proveedorToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void facturasAnterioresToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void agregarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            vee(new principal());
        }

        private void agregarToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            vee(new agregarprod());
        }

        private void clientesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            vee (new agregarcliente());
         
        }

        private void empleadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            agregarempl nj = new agregarempl();
            nj.Show();
        }

        private void comprasToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            agregarcompra anthony = new agregarcompra();
            anthony.Show();
        }

        private void cuentasPorCobrarToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            vee(new agregarcuentac());
        }

        private void proveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            vee(new agregarproveedor());
        }

        private void facturaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
           
        }

        private void nuevaFacturaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
        
        }

        private void productosToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void clientesToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {

        }

        private void ReportesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void clientesToolStripMenuItem1_Click_2(object sender, EventArgs e)
        {
            clientes mk = new clientes();
            mk.Show();
        }

        private void clienteToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void productosToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void facturarImpresionesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void empleadosToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            empleado bg = new empleado();
            bg.Show();
        }

        private void marcaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            marca kk = new marca();
            kk.Show();
        }

        private void productosToolStripMenuItem1_Click_2(object sender, EventArgs e)
        {
            productos oi = new productos();
            oi.Show();
        }

     

        private void facturasAnterioresToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            facturas fd = new facturas();
            fd.Show();
        }

        private void proveedoresToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            proveedores jj = new proveedores();
            jj.Show();
        }

        private void especificosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void productosToolStripMenuItem2_Click_1(object sender, EventArgs e)
        {
           
        }

        private void comprasToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            compra fi= new compra();
            fi.Show();
        }

        private void clientesToolStripMenuItem2_Click_1(object sender, EventArgs e)
        {

        }

        private void marcaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            vee(new agregarmarca());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Está seguro?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void productosToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            cliente aj = new cliente();
            aj.Show();
        }

        private void copiasEImpresionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            facturaimpresioncopia al = new facturaimpresioncopia();
            al.Show();
        }

        private void cuentasPorCobrarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           

        }

        private void comprasToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            comprasespc kk = new comprasespc();
            kk.Show();
        }

        private void cuentasPorCobrarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            cuentaporc nj = new cuentaporc();
            nj.Show();

        }

        private void clientesActivosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            reportdecuentac dd = new reportdecuentac();
            dd.Show();
        }

        private void clientesDeshabilitadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reportecuentacdesh kl = new reportecuentacdesh();
            kl.Show();
        }

        private void activosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void clientesActivosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clientesfactura pp = new clientesfactura();
            pp.Show();
        }

        private void generalesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
    
