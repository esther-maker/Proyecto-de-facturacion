﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class compra : Form
    {
        public compra()
        {
            InitializeComponent();
        }

        private void compra_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'BD.Compra' Puede moverla o quitarla según sea necesario.
          //  this.CompraTableAdapter.Fill(this.BD.Compra);


            this.reportViewer1.RefreshReport();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
