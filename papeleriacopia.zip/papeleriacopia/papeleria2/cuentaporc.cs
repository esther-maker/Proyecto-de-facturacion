﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class cuentaporc : Form
    {
        public cuentaporc()
        {
            InitializeComponent();
        }

        private void cuentaporc_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'BD.cuenta_cobrar' Puede moverla o quitarla según sea necesario.
            this.cuenta_cobrarTableAdapter.Fill(this.BD.cuenta_cobrar);

            this.reportViewer1.RefreshReport();
        }
    }
}
