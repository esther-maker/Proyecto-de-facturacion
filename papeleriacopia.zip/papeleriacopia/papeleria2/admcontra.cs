﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    
    public partial class admcontra : Form
    {
        public admcontra()
        {
            InitializeComponent();
        }
        conexion instancia = new conexion();

        private void admcontra_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = instancia.Listarusuario();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            instancia.insertarusuario(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
            MessageBox.Show("Insertado correctamente");
            dataGridView1.DataSource = instancia.Listarusuario();
        }
    }
}
