﻿namespace papeleria2
{
    partial class cuentcobrar1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reportactivoc = new Microsoft.Reporting.WinForms.ReportViewer();
            this.SuspendLayout();
            // 
            // reportactivoc
            // 
            this.reportactivoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportactivoc.Location = new System.Drawing.Point(0, 0);
            this.reportactivoc.Name = "reportactivoc";
            this.reportactivoc.Size = new System.Drawing.Size(689, 377);
            this.reportactivoc.TabIndex = 0;
            // 
            // cuentcobrar1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 377);
            this.Controls.Add(this.reportactivoc);
            this.Name = "cuentcobrar1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.cuentcobrar1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportactivoc;
    }
}