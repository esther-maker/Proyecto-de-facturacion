﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class agregarproveedor : Form
    {
        public agregarproveedor()
        {
            InitializeComponent();
        }
        conexion InstanciaBD = new conexion();
        bool Editar = false;


        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void agregarproveedor_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = InstanciaBD.Datosproveedor();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                Editar = true;
                id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                nombre.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox5.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                telefono.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            
            }

            else
            {
                MessageBox.Show("Seleccione una fila para utilizar Toolselection");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (Editar == false)
            {
                InstanciaBD.insertarprov(nombre.Text, textBox5.Text, telefono.Text);
                MessageBox.Show("Registro insertado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datosproveedor();
            }
            else
            {
                MessageBox.Show("Llene las casillas");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (Editar == false)
            {
                if (nombre.Text == "" || textBox5.Text == "" || telefono.Text == "")
                {
                    MessageBox.Show("Llene los campos o de uso de Toolselection");
                }
                else
                {
                    MessageBox.Show("Registro insertado correctamente");
                    InstanciaBD.insertarprov(nombre.Text, textBox5.Text, telefono.Text);
                    dataGridView1.DataSource = InstanciaBD.Datosproveedor();
                }

            }

            else if (Editar == true)
            {
                MessageBox.Show("Registro actualizado corectamente");
                InstanciaBD.actualizarprov(nombre.Text, textBox5.Text, telefono.Text, id.Text);
                dataGridView1.DataSource = InstanciaBD.Datosproveedor();
            }
            else
            {
                MessageBox.Show("Usa Toolselection");
            }












           
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                MessageBox.Show("Registro elminado");
                InstanciaBD.Eliminarprov(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                dataGridView1.DataSource = InstanciaBD.Datosproveedor();
            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            proveedores hg = new proveedores();
            hg.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("¿Desea limpiar los campos?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                id.Clear();
                nombre.Clear();
                textBox5.Clear();
                telefono.Clear();
            }

        }

        private void buscar_TextChanged(object sender, EventArgs e)
        {
            if (buscar.Text != "")
            {
                dataGridView1.DataSource = InstanciaBD.buscarproveedor(buscar.Text);
            }
            else
            {
                dataGridView1.DataSource = InstanciaBD.Datosproveedor();
            }
        }
    }
    }
    

