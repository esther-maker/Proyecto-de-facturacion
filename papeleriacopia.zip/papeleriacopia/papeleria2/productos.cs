﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class productos : Form
    {
        public productos()
        {
            InitializeComponent();
        }

        private void productos_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'BD.produto_marca_prov' Puede moverla o quitarla según sea necesario.
            this.produto_marca_provTableAdapter.Fill(this.BD.produto_marca_prov);
            // TODO: esta línea de código carga datos en la tabla 'BD.Productos' Puede moverla o quitarla según sea necesario.
            //this.ProductosTableAdapter.Fill(this.BD.Productos);


            // this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
