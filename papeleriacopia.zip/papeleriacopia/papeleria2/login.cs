﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace papeleria2
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            

        }
        private SqlConnection SQL = new SqlConnection("SERVER=DESKTOP-RNRG215\\SQLEXPRESS;DATABASE=papeleria;INTEGRATED SECURITY=TRUE");
        public static string nombre = "";
        cliente jj = new cliente();
        public void logear  (string USUARIO, string CONTRASEÑA)
        {
            try
            {
                SQL.Open();
                SqlCommand hhh = new SqlCommand("select  NOMBRE, TIPO_USUARIO FROM usuario WHERE usuario=@USUARIO and contraseña=@CONTRASEÑA ", SQL);
                hhh.Parameters.AddWithValue("usuario", USUARIO);
                hhh.Parameters.AddWithValue("contraseña", CONTRASEÑA);
                
                SqlDataAdapter ja = new SqlDataAdapter(hhh);
                DataTable dt = new DataTable();
                ja.Fill(dt);
              
                if (dt.Rows.Count == 1)
                {
                    this.Hide();
                    if (dt.Rows[0][1].ToString() == "ADM")
                    {
                        new afterlogin(dt.Rows[0][0].ToString()).Show();
                        

                    }
                    else if (dt.Rows[0][1].ToString() == "LOCAL")
                    {
                        new after2login(dt.Rows[0][0].ToString()).Show();
                        
                    }
                    else
                    {
                        MessageBox.Show("Usuario y/o contraseña incorrecta");
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);

            }
            finally
            {
                SQL.Close();
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                if (Contraseña.PasswordChar == '*')
                {
                    Contraseña.PasswordChar = '\0';

                }
            }
            else
            {
                Contraseña.PasswordChar = '*';
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            logear(this.usuario.Text, this.Contraseña.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                Contraseña.Focus();
            }
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                button1.Focus();
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
           
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
           
        }

        private void Contraseña_Leave(object sender, EventArgs e)
        {
           
        }
    }
    }
    

