﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class agregarcompra : Form
    {
        public agregarcompra()
        {
            InitializeComponent();

        }
        conexion InstanciaBD = new conexion();
        double total;
   
        bool Editar = false;
        private void ListarMarcas()
        {
            comboBox1.DataSource = InstanciaBD.ListarMarcas();
            comboBox1.DisplayMember = "marca";
            comboBox1.ValueMember = "codigo_marca";
        }
        private void ListarProveedor()
        {
            proveedor.DataSource = InstanciaBD.ListProveedor();
            proveedor.DisplayMember = "nombre";
            proveedor.ValueMember = "id_prov";
        }

        private void agregarcompra_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'basededatos.marca' Puede moverla o quitarla según sea necesario.
           // this.marcaTableAdapter.Fill(this.basededatos.marca);

            ListarMarcas();
            ListarProveedor();
            dataGridView1.DataSource = InstanciaBD.Datoscompra();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            agregarmarca bine = new agregarmarca();
            bine.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            agregarproveedor bi = new agregarproveedor();
            bi.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            agregarprod be = new agregarprod();
            be.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void fecha_ValueChanged(object sender, EventArgs e)
        {

        }

        private void proveedor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
           
        }

        private void agregprod_Click(object sender, EventArgs e)
        {


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (Editar == false)
            {
                if ( precio_unid.Text == "" || cantidad.Text == "" || cod_prod.Text == "" || precio_total.Text == "")
                {
                    MessageBox.Show("Llene los campos");
                }
                else
                {
                    InstanciaBD.insertarcompra(proveedor.SelectedValue.ToString(), precio_unid.Text, cantidad.Text, cod_prod.Text, comboBox1.SelectedValue.ToString(), precio_total.Text );
                    MessageBox.Show("Insertado correctamente");
                    dataGridView1.DataSource = InstanciaBD.Datoscompra();
                }

            }

            else if (Editar == true)
            {
                InstanciaBD.actualizarcompra(proveedor.SelectedValue.ToString(), DateTime.Now.ToLongDateString(), precio_unid.Text, cantidad.Text, cod_prod.Text, comboBox1.SelectedValue.ToString(), precio_total.Text, textBox1.Text);
                MessageBox.Show("Actualizado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datoscompra();
                Editar = false;
            }
            else
            {
                MessageBox.Show("Usa Toolselection");
            }

        }
    

        private void button10_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                InstanciaBD.Eliminarcompra(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Registro eliminado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datoscompra();

            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea limpiar los campos?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                textBox1.Clear();
      
                precio_unid.Clear();
                cantidad.Clear();
                cod_prod.Clear();
                precio_total.Clear();
            }
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                Editar = true;
                textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                proveedor.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                fecha.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                precio_unid.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                cantidad.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                cod_prod.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                comboBox1.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                precio_total.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();

            }

            else
            {
                MessageBox.Show("Seleccione una fila para utilizar Toolselection");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            agregarprod ll = new agregarprod();
            ll.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            total = Convert.ToDouble(precio_unid.Text) * Convert.ToDouble(cantidad.Text) + total;
             precio_total.Text = Convert.ToString(total);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

