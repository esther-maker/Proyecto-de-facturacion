﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class agregarmarca : Form
    {
        public agregarmarca()
        {
            InitializeComponent();
        }
        bool Editar = false;
        conexion InstanciaBD = new conexion();


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void agregarmarca_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'papeleriafuenteDataSet8.marca' Puede moverla o quitarla según sea necesario.
            //this.marcaTableAdapter.Fill(this.papeleriafuenteDataSet8.marca);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
        }



        private void agregarmarca_Load_1(object sender, EventArgs e)
        {
            dataGridView2.DataSource = InstanciaBD.Datosmarca();
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (codigo.Text == "Código")
                codigo.Text = "";
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (codigo.Text == "")
                codigo.Text = "Código";
        }


        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (Editar == false)
            {
                InstanciaBD.insertarmarca(textBox3.Text);
                MessageBox.Show("Actualizado");
                dataGridView2.DataSource = InstanciaBD.Datosmarca();
                Editar = false;
                textBox3.Clear();
            }
        }

        private void nombre_Enter(object sender, EventArgs e)
        {

        }
        private void nombre_Leave(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (dataGridView2.SelectedRows.Count < 0)
            {
                Editar = true;
                codigo.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                textBox3.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            }

            else
            {
                MessageBox.Show("Seleccione una fila");

            }
        }
        private void nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_Enter_1(object sender, EventArgs e)
        {
            if (textBox3.Text == "Nombre de la marca")
                textBox3.Text = "";
        }

        private void textBox3_Leave_1(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
                textBox3.Text = "Nombre de la marca";
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

            if (dataGridView2.SelectedRows.Count > 0)
            {
                Editar = true;
                codigo.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                textBox3.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            }

            else
            {
                MessageBox.Show("Seleccione una fila para utilizar Toolselection","",MessageBoxButtons.OK ,MessageBoxIcon.Exclamation);

            }
        }

        private void eliminar_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (Editar == false)
            {
                InstanciaBD.insertarmarca(textBox3.Text);
                MessageBox.Show("Registro insertado correctamente");
                dataGridView2.DataSource = InstanciaBD.Datosmarca();
                Editar = false;

            }
            else
            {
                MessageBox.Show("Llene correctamente las casillas"); 
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (Editar == false)
            {
                if (marca.Text == "")
                {
                    MessageBox.Show("Llene los campos");
                }
                else
                {
                 
                    InstanciaBD.insertarmarca(textBox3.Text);
                    MessageBox.Show("Registro insertado corrrectamente");
                    dataGridView2.DataSource = InstanciaBD.Datosmarca();
                    dataGridView1.Refresh();
                }

            }

            else if (Editar == true)
            {
           
                InstanciaBD.actualizarmarca(textBox3.Text, codigo.Text);
                MessageBox.Show("Actualizado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datosmarca();
                dataGridView1.Refresh();
                Editar = false;
            }
            else
            {
                MessageBox.Show("Usa Toolselection");
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            marca prr = new marca();
            prr.Show();

        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                InstanciaBD.Eliminarmarca(dataGridView2.CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Registro elminado correctamente");
                dataGridView2.DataSource = InstanciaBD.Datosmarca();
            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

            {
               if (MessageBox.Show("¿Desea limpiar los campos?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) 
                {
                    codigo.Clear();
                    textBox3.Clear();
                }
               
              
    
                    
                
           
               
            }
           
            
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox4.Text != "")
            {
                dataGridView2.DataSource = InstanciaBD.buscarmarca(textBox4.Text);
            }
            else
            {
                dataGridView2.DataSource = InstanciaBD.Datosmarca();
            }
        }
    }
    }
