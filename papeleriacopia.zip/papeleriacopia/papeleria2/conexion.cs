﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace papeleria2
{
    public class conexion
    {

        private SqlConnection SQL = new SqlConnection("SERVER=DESKTOP-RNRG215\\SQLEXPRESS;DATABASE=papeleria;INTEGRATED SECURITY=TRUE");
        private DataSet DS; //un dataset guarda varias tablas llamadas datatable que sirve para mostrar los  datos
        private void Abrir()//metodo para abrir la conexion si esta cerrada
        {
            if (SQL.State == ConnectionState.Closed)
            {
                SQL.Open();
            }
        }

        private void Cerrar()
        {
            if (SQL.State == ConnectionState.Open)
            {
                SQL.Close();
            }
        }

        public DataTable DatosProductos()
        {

            SqlCommand comando = new SqlCommand("SELECT codigo_prod,Productos.nombre,Productos.cantidad, marca.marca,Productos.precio_unit, proveedores.nombre as proveedor from Productos inner join marca on marca.codigo_marca = Productos.marca inner join proveedores on proveedores.id_prov = Productos.proveedor where cantidad >0", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");

            return DS.Tables["herencia"];
        }
        public DataTable Datosclientes()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT * from clientes where estado=1", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public DataTable Datosclientes2()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT * from clientes where estado=0", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public DataTable contarclientes()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("select count(Cod_cliente) as Total_registros from clientes where estado=1", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public DataTable contarclientes2()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("select count(Cod_cliente) as Total_registros from clientes where estado=0", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public bool insertarproductos(string nombre, string cantidad, string marca, string precio_unit, string proveedor)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO Productos(nombre,cantidad,marca,precio_unit,proveedor) VALUES ('{0}',{1},{2},{3},{4})", new string[] { nombre, cantidad, marca, precio_unit, proveedor }), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;
        }

        public bool Eliminar(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("DELETE FROM productos WHERE codigo_prod = {0}", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            if (afectado > 0) return true;
            else return false;
        }

        public DataTable ListarMarcas()
        {
            SQL.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM marca", SQL);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DS = new DataSet();
            sda.Fill(DS, "tabla");
            SQL.Close();
            return DS.Tables["tabla"];
        }


        public DataTable ListProveedor()
        {
            SQL.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM proveedores", SQL);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DS = new DataSet();
            sda.Fill(DS, "tabla");
            SQL.Close();
            return DS.Tables["tabla"];


        }

        public bool actualizarproductos(string Nombre, string Cantidad, string Marca, string Precio, string Proveedor, string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update Productos set nombre='{0}', cantidad={1}, marca={2},precio_unit ={3},proveedor={4} where codigo_prod  = '{5}'", new string[] { Nombre, Cantidad, Marca, Precio, Proveedor, ID }), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public bool Eliminarclientes2(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update clientes set estado=1 where cod_cliente = '{0}'", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;

        }

        public bool Eliminarcopia(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("delete from copiaeimpresion1  where cod_ci = '{0}'", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;

        }

        public bool Eliminarclientes(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update clientes set estado=0 where cod_cliente = '{0}'", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;

        }
        public bool insertarcliente(string Nombre, string Apellido, string Edad, string Telefono, string direccion, string genero)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO clientes(nombre, apellido, edad, telefono, direccion, Genero,estado) VALUES('{0}','{1}',{2},'{3}','{4}','{5}',1)", new string[] { Nombre, Apellido, Edad, Telefono, direccion, genero }), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;



        }
        public bool insertarempleados(string nombre, string apellido, string cedula, string edad, string telefono, string correo_electronico, string direccion, string Genero, string sueldo, string id)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO empleados (nombre,apellido, cedula, edad, telefono, correo_electronico, direccion, Genero, sueldo, estado) values ('{0}','{1}','{2}',{3},'{4}','{5}','{6}','{7}',{8}, 1)", new string[] { nombre, apellido, cedula, edad, telefono, correo_electronico, direccion, Genero, sueldo, id }), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;
        }

        public bool actualizarempleados(string nombre, string apellido, string cedula, string edad, string telefono, string correo_electronico, string direccion, string Genero, string sueldo)

        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("UPDATE empleados set  nombre='{0}', apellido='{1}', cedula='{2}', edad='{3}', telefono='{4}', correo_electronico='{5}', direccion = '{6}', Genero='{7}', sueldo={8}", new string[] { nombre, apellido, cedula, edad, telefono, correo_electronico, direccion, Genero, sueldo }), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }



        public bool actualizarclientes(string Nombre, string apellido, string edad, string telefono, string genero, string direccion, string id)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update clientes set nombre='{0}', apellido='{1}', edad={2}, telefono={3}, Genero='{4}', direccion='{5}' where cod_cliente = '{6}'", new string[] { Nombre, apellido, edad, telefono, genero, direccion, id }), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public bool Eliminarempleados(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update empleados set estado=0 where cod_empleado = '{0}'", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public bool activoempleados(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update empleados set estado=1 where cod_empleado = '{0}'", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }


        public DataTable buscar(string nombre)
        {
            SQL.Open();
            SqlCommand hija = new SqlCommand(string.Format("select * from empleados where nombre like '%{0}%' and estado = 1", nombre), SQL);
            SqlDataAdapter pr = new SqlDataAdapter(hija);
            DS = new DataSet();
            pr.Fill(DS, "table");
            SQL.Close();
            return DS.Tables["table"];

        }

        public DataTable buscarcliente(string nombre)
        {
            SQL.Open();
            SqlCommand hija = new SqlCommand(string.Format("select Cod_cliente, nombre, apellido from clientes where nombre like '%{0}%' and estado=1", nombre), SQL);
            SqlDataAdapter pr = new SqlDataAdapter(hija);
            DS = new DataSet();
            pr.Fill(DS, "table");
            SQL.Close();
            return DS.Tables["table"];

        }
        public DataTable buscarproveedor(string nombre)
        {
            SQL.Open();
            SqlCommand hija = new SqlCommand(string.Format("select * from proveedores where nombre like '%{0}%'", nombre), SQL);
            SqlDataAdapter pr = new SqlDataAdapter(hija);
            DS = new DataSet();
            pr.Fill(DS, "table");
            SQL.Close();
            return DS.Tables["table"];

        }

        public DataTable buscarproductos(string nombre)
        {
            SQL.Open();
            SqlCommand hija = new SqlCommand(string.Format("select * from Productos where nombre like '%{0}%'", nombre), SQL);
            SqlDataAdapter pr = new SqlDataAdapter(hija);
            DS = new DataSet();
            pr.Fill(DS, "table");
            SQL.Close();
            return DS.Tables["table"];

        }
        public DataTable buscarmarca(string nombre)
        {
            SQL.Open();
            SqlCommand hija = new SqlCommand(string.Format("select * from marca where marca like '%{0}%'", nombre), SQL);
            SqlDataAdapter pr = new SqlDataAdapter(hija);
            DS = new DataSet();
            pr.Fill(DS, "table");
            SQL.Close();
            return DS.Tables["table"];

        }
        public DataTable Datosempleadosactivos()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT cod_empleado, nombre, apellido, cedula, edad, telefono, correo_electronico, direccion, Genero, sueldo from empleados where estado = 1", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public DataTable Datosempleadosact()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT * from empleados where estado = 0", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public bool actualizarmarca(string marca, string id)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update marca set marca='{0}' where codigo_marca= '{1}'", new string[] { marca, id }), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public DataTable Datosmarca()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT * from  marca", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public DataTable Datosclie()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT Cod_cliente, nombre, apellido from  clientes where estado=1 ", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public bool Eliminarmarca(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("DELETE FROM marca WHERE codigo_marca = {0}", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public DataTable Datosclientes3()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT Cod_cliente, nombre, apellido from clientes where estado=1", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public DataTable Datoscompra()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("select Compra.id_comp, proveedores.nombre, Compra.fecha_compra, Compra.precio_unid, Compra.cantidad, Compra.codigo_prod, marca.marca, Compra.precio_total from Compra inner join proveedores on Compra.proveedor = proveedores.id_prov inner join marca on Compra.marca = marca.codigo_marca", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }

        public bool insertarcompra(string proveedor, string precio_unid, string cantidad, string codigo_prod, string marca, string precio_total)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO Compra (proveedor, fecha_compra, precio_unid, cantidad, codigo_prod, marca, precio_total) VALUES ('{0}', Getdate(),'{1}','{2}','{3}','{4}','{5}')", new string[] { proveedor, precio_unid, cantidad, codigo_prod, marca, precio_total}), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;
        }
        public bool actualizarcompra(string proveedor, string fecha_compra, string precio_unid, string cantidad, string codigo_prod, string marca, string precio_total, string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update cuenta_cobrar set fecha='{0}', monto_pagar='{1}', Cod_cliente={2} where id_cobrar= {3}", new string[] { proveedor, fecha_compra, precio_unid, cantidad, codigo_prod, marca, precio_total, ID }), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public bool Eliminarcompra(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("DELETE FROM Compra WHERE id_comp = {0}", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public bool insertarmarca(string nombre)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO marca VALUES('{0}')", new string[] { nombre }), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;
        }
        public bool insertarcuentas(string monto_pagar, string cod_clit, string fecha)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(("insertarCobrar"), SQL);
            comando.CommandType = CommandType.StoredProcedure;
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;

        }


        public void insertarcuenta(DateTime fecha, double monto_pagar, int cod_clit)
        {

            SQL.Open();

            using (var Command = new SqlCommand())
            {
                Command.Connection = SQL;
                Command.CommandText = "insertarCobrar";
                Command.CommandType = CommandType.StoredProcedure;
                Command.Parameters.AddWithValue("@feha", fecha);
                Command.Parameters.AddWithValue("@monto", monto_pagar);
                Command.Parameters.AddWithValue("@codcliente", cod_clit);

                SqlDataReader reader = Command.ExecuteReader();

                Command.Parameters.Clear();


            }



        }
        public bool insertarusuario(string Nombre, string usuario, string contraseña, string cod_emp)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO usuario ( NOMBRE, USUARIO, CONTRASEÑA , TIPO_USUARIO, cod_empleado) VALUES('{0}','{1}','{2}', LOCAL, {4})", new string[] { Nombre, usuario, contraseña, cod_emp }), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;
        }

        public DataTable Datoscuenta1()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT cuenta_cobrar.id_cobrar,cuenta_cobrar.fecha,cuenta_cobrar.monto_pagar,clientes.nombre, clientes.apellido  from cuenta_cobrar inner join clientes on cuenta_cobrar.Cod_cliente = clientes.Cod_cliente where clientes.estado = 1", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public DataTable Datoscuenta2()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT cuenta_cobrar.id_cobrar,cuenta_cobrar.fecha,cuenta_cobrar.monto_pagar,clientes.nombre, clientes.apellido  from cuenta_cobrar inner join clientes on cuenta_cobrar.Cod_cliente = clientes.Cod_cliente where clientes.estado = 0", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public DataTable Datoscuenta()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT cuenta_cobrar.id_cobrar,cuenta_cobrar.fecha,cuenta_cobrar.monto_pagar,cuenta_cobrar.Cod_cliente,clientes.nombre  from cuenta_cobrar inner join clientes on cuenta_cobrar.Cod_cliente = clientes.Cod_cliente", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public bool actualizarcuenta(string fecha, string monto_pagar, string Cod_cliente, string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("update cuenta_cobrar set fecha='{0}', monto_pagar={1}, Cod_cliente={2} where id_cobrar= {3}", new string[] { fecha, monto_pagar, Cod_cliente, ID }), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public bool Eliminarcuenta(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("DELETE FROM cuenta_cobrar WHERE id_cobrar = '{0}'", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public DataTable Datosproveedor()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT * from proveedores", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public bool insertarprov(string nombre, string Direccion, string Telefono)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO proveedores VALUES('{0}','{1}','{2}')", new string[] { nombre, Direccion, Telefono }), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;

        }
        public bool actualizarprov(string nombre, string Direccion, string Telefono, string id)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("UPDATE proveedores set nombre='{0}', Direccion='{1}', Telefono='{2}' where id_prov= {3}", new string[] { nombre, Direccion, Telefono, id }), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public bool Eliminarprov(string ID)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("DELETE FROM proveedores WHERE id_prov = {0}", ID), SQL);
            int afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (afectado > 0) return true;
            else return false;
        }
        public DataTable Datosfactura()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT factura.codigo_fact, empleados.nombre as [Nombre empleado], empleados.apellido as [apellido empleado], clientes.nombre AS [nombre cliente], clientes.apellido AS [apellido cliente], factura.fecha, cuenta_cobrar.id_cobrar, cuenta_cobrar.monto_pagar,  Productos.nombre AS [Nombre producto], marca.marca, detalle_factura.cantidad, detalle_factura.precio, detalle_factura.preciototal, detalle_factura.monto, detalle_factura.devuelta FROM Productos INNER JOIN detalle_factura ON Productos.codigo_prod = detalle_factura.cod_prod INNER JOIN marca ON Productos.marca = marca.codigo_marca CROSS JOIN clientes INNER JOIN cuenta_cobrar ON clientes.Cod_cliente = cuenta_cobrar.Cod_cliente INNER JOIN factura ON clientes.Cod_cliente = factura.Cod_cliente AND cuenta_cobrar.id_cobrar = factura.id_cuentac CROSS JOIN empleados", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public bool insertardetallefactura(string cod_fact, string Cod_producto, string cantidad, string precio,string preciototal, string monto, string devuelta)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO detalle_factura VALUES({0},{1},{2},{3},{4},{5},{6})", new string[] {cod_fact, Cod_producto,cantidad, precio,preciototal,monto,devuelta }), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;
        }


        public void guardarDetalle(int cod_fact, int Cod_Producto, int cantidad, double precioU, double preciototal, double monto, double devuelta)
        {
          
                SQL.Open();

                using (var Command = new SqlCommand())
                {
                Command.Connection = SQL;
                    Command.CommandText = "GuardardETalle";

                    Command.CommandType = CommandType.StoredProcedure;
                    Command.Parameters.AddWithValue("@codFact", cod_fact);
                    Command.Parameters.AddWithValue("@codprod", Cod_Producto);
                    Command.Parameters.AddWithValue("@cantidad", cantidad);
                    Command.Parameters.AddWithValue("@precio", precioU);

                    Command.Parameters.AddWithValue("@preciototal", preciototal);
                Command.Parameters.AddWithValue("@monto", monto);

                Command.Parameters.AddWithValue("@devuelta", devuelta);


                SqlDataReader reader = Command.ExecuteReader();
                    Command.Parameters.Clear();
                }

            }
        



        public void guardarFact(int Cod_Empleado, int Cod_Cliente, DateTime Fecha, int codmonto)
        {
           
           
                SQL.Open();

                using (var Command = new SqlCommand())
                {
                    Command.Connection =SQL;
                    Command.CommandText = "GuardarFactura";

                    Command.CommandType = CommandType.StoredProcedure;
                    Command.Parameters.AddWithValue("@codEmpleado", Cod_Empleado);
                    Command.Parameters.AddWithValue("@codCliente", Cod_Cliente);
                    Command.Parameters.AddWithValue("@fecha", Fecha);
                    Command.Parameters.AddWithValue("@id_cuenta", codmonto);


                    SqlDataReader reader = Command.ExecuteReader();
                    Command.Parameters.Clear();
                }

            }


        public bool insertarfactura(string Cod_empleado, string cod_cliente, string fecha, string id_cuenta)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO factura VALUES({0},{1},{2},{3})", new string[] { Cod_empleado, cod_cliente, fecha, id_cuenta }), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;
        }
        public DataTable Datoscopia()
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand("SELECT modos.modo, copiaeimpresion1.cantidad,  copiaeimpresion1.fecha, copiaeimpresion1.precio, copiaeimpresion1.precio_total, copiaeimpresion1.monto_pagado, copiaeimpresion1.devuelta from copiaeimpresion1 inner join modos on copiaeimpresion1.id_modo = modos.id_modo ", SQL);
            SqlDataAdapter adaptador = new SqlDataAdapter(comando);
            DS = new DataSet();
            adaptador.Fill(DS, "herencia");
            SQL.Close();
            return DS.Tables["herencia"];
        }
        public bool insertarcopia(string modo, string cantidad ,  string precio, string precio_total, string monto_pagado, string devuelta, string id)
        {
            SQL.Open();
            SqlCommand comando = new SqlCommand(string.Format("INSERT INTO copiaeimpresion1 (id_modo, cantidad, fecha, precio, precio_total, monto_pagado, devuelta)  VALUES ('{0}',{1},Getdate(),{2},{3},{4},{5})", new string[] {modo, cantidad, precio, precio_total, monto_pagado, devuelta, id}), SQL);
            int Afectado = comando.ExecuteNonQuery();
            SQL.Close();
            if (Afectado > 0) return true;
            else return false;

        }
        public DataTable ListarModos()
        {
            SQL.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM modos", SQL);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DS = new DataSet();
            sda.Fill(DS, "tabla");
            SQL.Close();
            return DS.Tables["tabla"];
        }


        public string idmonto()
        {

            SQL.Open();
            string Resultado1 = "null";
            string query1 = "SELECT (SELECT DISTINCt TOP 1 id_cobrar from cuenta_cobrar order by id_cobrar desc)+1 as id_cobrar";
            SqlCommand comandos1 = new SqlCommand(query1, SQL);
            SqlDataReader reg1 = comandos1.ExecuteReader();

            if (reg1.Read())
            {
                Resultado1 = reg1["id_cobrar"].ToString();

            }
            SQL.Close();


            return Resultado1;

        }




        public string idfact()
        {

            SQL.Open();
            string Resultado1 = "null";
            string query1 = "SELECT (SELECT DISTINCt TOP 1 codigo_fact from factura order by codigo_fact desc)+1 as codigo_fact";
            SqlCommand comandos1 = new SqlCommand(query1, SQL);
            SqlDataReader reg1 = comandos1.ExecuteReader();

            if (reg1.Read())
            {
                Resultado1 = reg1["codigo_fact"].ToString();

            }
            SQL.Close();


            return Resultado1;

        }
        public string idcop()
        {

            SQL.Open();
            string Resultado1 = "null";
            string query1 = "SELECT (SELECT DISTINCt TOP 1 cod_ci from copiaeimpresion1 order by cod_ci desc)+1 as cod_ci";
            SqlCommand comandos1 = new SqlCommand(query1, SQL);
            SqlDataReader reg1 = comandos1.ExecuteReader();

            if (reg1.Read())
            {
                Resultado1 = reg1["cod_ci"].ToString();

            }
            SQL.Close();


            return Resultado1;

        }


        public DataTable Listarusuario()
        {
            SQL.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM usuario", SQL);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DS = new DataSet();
            sda.Fill(DS, "tabla");
            SQL.Close();
            return DS.Tables["tabla"];
        }


    }
}



