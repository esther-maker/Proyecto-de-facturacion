﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using milibreria;
using System.Data.SqlClient;


namespace papeleria2
{
    public partial class cliente : Form
    {
        public cliente()
        {
            InitializeComponent();
            
            textBox1.Enabled = false;
            textBox5.Text = klk.idmonto();
            label8.Text = klk.idfact();
            
        }
        conexion klk = new conexion();
        public bool Editar = false;
        public static int contador = 0;


        public SqlConnection Conexion = new SqlConnection("SERVER=DESKTOP-RNRG215\\SQLEXPRESS;DATABASE=papeleria;INTEGRATED SECURITY=TRUE");
        public SqlCommand comando1 = new SqlCommand();
        DataSet ds = new DataSet();

        private void factura_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'basededatos.facturas' Puede moverla o quitarla según sea necesario.

            fecha.Text = DateTime.Now.ToShortDateString();
            // dataGridView1.DataSource = klk.Datosfactura();
           

            
        }

       
        


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

            //  if (nombremp.Text != "")
            {
                //     dataGridView2.DataSource = klk.buscar(nombremp.Text);
            }
            // else
            {
                //      dataGridView2.DataSource = klk.Datosempleadosactivos();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {



        }

        public void codigoemp_TextChanged(object sender, EventArgs e)
        {
            // codigoemp.Text = codigoprod.Text;
            //dataGridView4.CurrentRow.Cells[0].Value.ToString();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            agregarcliente jd = new agregarcliente();
            jd.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {


        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }



        private void button9_Click(object sender, EventArgs e)
        {
        }


        private void nombreclit_TextChanged(object sender, EventArgs e)
        {
            {
                // if (nombreclit.Text != "")
                {
                    //     dataGridView3.DataSource = klk.buscarcliente(nombreclit.Text);
                }
                // else
                {
                    //    dataGridView3.DataSource = klk.Datosclientes();
                }
            }
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            //  if (dataGridView4.SelectedRows.Count > 0)
            {
                Editar = false;
                //   dataGridView4.DataSource = klk.DatosProductos();
                //   codigoprod.Text = dataGridView4.CurrentRow.Cells[0].Value.ToString();
                //   nombreprod.Text = dataGridView4.CurrentRow.Cells[1].Value.ToString();
                //   textBox2.Text = dataGridView4.CurrentRow.Cells[3].Value.ToString();
                //  precioprod.Text = dataGridView4.CurrentRow.Cells[4].Value.ToString();
            }
        }

        private void nombreprod_TextChanged(object sender, EventArgs e)
        {
            {
                //   if (nombreprod.Text != "")
                //   {
                //      dataGridView4.DataSource = klk.buscarproductos(nombreprod.Text);
                //  }
                //  else
                {
                    //     dataGridView4.DataSource = klk.DatosProductos();
                }
            }
        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //  codigoprod.Text = dataGridView4.CurrentRow.Cells[0].Value.ToString();
            //  nombreprod.Text = dataGridView4.CurrentRow.Cells[1].Value.ToString();
            //   precioprod.Text = dataGridView4.CurrentRow.Cells[4].Value.ToString();
        }

        private void nombremp_Enter(object sender, EventArgs e)
        {

        }

        private void nombremp_Leave(object sender, EventArgs e)
        {

        }

        private void fecha_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            //  textBox7.Text = Convert.ToString(total);
            //  total = total + Convert.ToDouble(preciocopia.Text) + Convert.ToDouble(precioimp.Text) + Convert.ToDouble(preciocopia.Text) + Convert.ToDouble(precioprod.Text);

        }


        private void button7_Click(object sender, EventArgs e)
        {
            // totalcop = Convert.ToDouble(textBox13.Text) * Convert.ToDouble(textBox14.Text) + totalcop;
            // preciocopia.Text = Convert.ToString(totalcop);
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            //totalprod = Convert.ToDouble(precioprod.Text) * Convert.ToDouble(cantidadprod.Text) + totalprod;
            //  precioproductos.Text = Convert.ToString(totalprod);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // totalimp = Convert.ToDouble(textBox16.Text) * Convert.ToDouble(textBox15.Text) + totalimp;
            // precioimp.Text = Convert.ToString(totalimp);
        }

        private void preciocopia_TextChanged(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            // devuelta = Convert.ToDouble(monto.Text) - Convert.ToDouble(textBox7.Text);
            //  textBox12.Text = Convert.ToString(devuelta);
        }

        private void button10_Click(object sender, EventArgs e)
        {

            //  double a = Convert.ToDouble(precioprod.Text);
            //  double b = Convert.ToDouble(cantidadprod.Text);

            // double r = a * b;
            // label9.Text = r.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (cont>0)
            {
                total2 = total2 - (Convert.ToDouble(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[4].Value));
                textBox6.Text = "RD$" + total2.ToString();
                dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                cont--;
            }
        }
        public static int cont = 0;
        public static double total2;
        string[,] ListarProducto = new string[200, 200];
        int fila = 0;
        private void button11_Click(object sender, EventArgs e)
        {

            try
            {
                if (codigo2.Text != "" && nombreprod.Text != "" && cantidadprod.Text != "" && precioprod.Text != "")
                {
                    ListarProducto[fila, 0] = codigo2.Text;
                    ListarProducto[fila, 1] = nombreprod.Text;

                    ListarProducto[fila, 2] = cantidadprod.Text;
                    ListarProducto[fila, 3] = precioprod.Text;
                    ListarProducto[fila, 4] = (double.Parse(cantidadprod.Text) * double.Parse(precioprod.Text)).ToString();

                    dataGridView1.Rows.Add(ListarProducto[fila, 0], ListarProducto[fila, 1], ListarProducto[fila, 2], ListarProducto[fila, 3], ListarProducto[fila, 4], ListarProducto[fila, 5]);
                    fila++;

                    codigo2.Text = nombreprod.Text = cantidadprod.Text = precioprod.Text = "";


                    codigo2.Focus();
                    this.codigo2.Clear();
                    this.nombreprod.Clear();

                    this.cantidadprod.Clear();
                    this.precioprod.Clear();



                }
                else
                {
                    MessageBox.Show("No hay nada que agregar, están vacios los textbox");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se Puede Agregar este Producto" + ex);
            }
            CostoApagar();
        }


    

    private void nombreclit_Enter(object sender, EventArgs e)
        {
           
        }
        public void CostoApagar()
        {


            double CostoTotal = 0;
            int Conteo = 0;

            Conteo = dataGridView1.RowCount;

            for (int i = 0; i < Conteo; i++)
            {

                CostoTotal += Convert.ToDouble(dataGridView1.Rows[i].Cells[4].Value);


            }
            textBox6.Text = CostoTotal.ToString();

        }

        private void nombreprod_Enter(object sender, EventArgs e)
        {
           // if (nombreprod.Text == "Buscar")
            //    nombreprod.Text = "";
        }

        private void nombreclit_Leave(object sender, EventArgs e)
        {
          
        }

        private void nombreprod_Leave(object sender, EventArgs e)
        {
          
        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click_1(object sender, EventArgs e)
        {

        }

        private void cuentac_TextChanged(object sender, EventArgs e)
        {

        }
       
        rhtml InstanciaBD = new rhtml();


        private void button12_Click(object sender, EventArgs e)
        {
            InstanciaBD.Insertarmonto(DateTime.Now.ToLongDateString(),textBox1.Text, codigo.Text);
            MessageBox.Show("Guardado correctamente");
            button12.Enabled = false;
            button8.Enabled = true;
           

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Está seguro de cancelar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button5_Click_2(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Proceso de factura, ¿está seguro de abrir nueva?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {

                cliente aj = new cliente();
                aj.Show();
            }
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            double c = Convert.ToDouble(monto.Text);
            double d = Convert.ToDouble(textBox6.Text);

            double o = c - d;
            label16.Text = o.ToString();
            if (o <= -0)
            {
                if (MessageBox.Show("El cliente a superado su presupuesto, ¿desea guardar cuenta por pagar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    groupBox4.Show();
                    
                    textBox1.Text = label16.Text;
                  
                }
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void codigofact_TextChanged(object sender, EventArgs e)
        {

        }
        rhtml jj = new rhtml();
        private void button8_Click_1(object sender, EventArgs e) 
        {


            try
            {

                if (groupBox4.Visible == true)
                {

                    jj.guardarFact(textBox4.Text, codigo.Text, DateTime.Now.ToLongDateString(), textBox5.Text);
                    MessageBox.Show("Se guardo correctamente");

                }
                else
                {
                    jj.guardarFact(textBox4.Text, codigo.Text, DateTime.Now.ToLongDateString(), label11.Text);
                    MessageBox.Show("Se guardo correctamente");
                }
            }
            catch(Exception maria)
            {
                MessageBox.Show("Eso ta malisimo"+ maria);
            }


            try
            {
                if (groupBox4.Visible == true)
                {


                    foreach (DataGridViewRow d in dataGridView1.Rows)
                    {
                        rhtml jjj = new rhtml();
                        jjj.guardardetalle(label8.Text, d.Cells[0].Value.ToString(), d.Cells[2].Value.ToString(), d.Cells[3].Value.ToString(), d.Cells[4].Value.ToString(), monto.Text, textBox1.Text);
                        label8.Text = klk.idfact();
                        groupBox4.Visible = false;
                        monto.Clear();
                        textBox2.Clear();
                        textBox4.Clear();
                        codigo.Clear();
                        label16.Text = "0.00";
                        textBox3.Clear();
                        textBox6.Text = "0.00";
                        if (MessageBox.Show("La informacion guardada se imprimirá", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) == DialogResult.OK)
                        {                                               
                        }
                                           }
                                    }
                else
                {

                    foreach (DataGridViewRow d in dataGridView1.Rows)
                    {
                        rhtml jjj = new rhtml();
                        jjj.guardardetalle(label8.Text, d.Cells[0].Value.ToString(), d.Cells[2].Value.ToString(), d.Cells[3].Value.ToString(), d.Cells[4].Value.ToString(), monto.Text, label16.Text);
                        
                        
                        groupBox4.Visible = false;

                        if (MessageBox.Show("La informacion guardada se imprimirá", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) == DialogResult.OK)
                        {
                            //Creamos una instancia d ela clase CrearTicket
                            ticker ticket = new ticker();
                            //Ya podemos usar todos sus metodos
                            ticket.AbreCajon();//Para abrir el cajon de dinero.

                            //De aqui en adelante pueden formar su ticket a su gusto... Les muestro un ejemplo

                            //Datos de la cabecera del Ticket.
                            ticket.TextoCentro("Papelería Malvi");
                            ticket.TextoIzquierda("Dirección: C/ Pedro Arana");
                            ticket.TextoIzquierda("Teléfono: 000000000");
                            ticket.TextoIzquierda("Email: papeleriamalvi01@gmail.com");//Es el mio por si me quieren contactar ...
                            ticket.TextoExtremos("Fecha: " + DateTime.Now.ToShortDateString(), "Hora: " + DateTime.Now.ToShortTimeString());
                            ticket.TextoIzquierda("Ticket #:" + label8.Text.ToString());
                            ticket.lineasAsteriscos();

                            //Sub cabecera.

                            ticket.TextoIzquierda("Cliente:" + textBox3.Text);
                            ticket.TextoIzquierda("Empleado:" + textBox2.Text);
                            ticket.lineasAsteriscos();

                            //Articulos a vender.
                            ticket.EncabezadoVenta();//NOMBRE DEL ARTICULO, CANT, PRECIO
                            ticket.lineasAsteriscos();
                            //Si tiene una DataGridView donde estan sus articulos a vender pueden usar esta manera para agregarlos al ticket.
                            foreach (DataGridViewRow fila in dataGridView1.Rows)//dgvLista es el nombre del datagridview
                            {
                                ticket.AgregaArticulo(int.Parse(fila.Cells[0].Value.ToString()), fila.Cells[1].Value.ToString(), int.Parse(fila.Cells[2].Value.ToString()), decimal.Parse(fila.Cells[3].Value.ToString()));
                            }

                            ticket.lineasIgual();
                            ticket.TextoIzquierda("         TOTAL.........$" + textBox6.Text);
                            ticket.TextoIzquierda("         EFECTIVO......$" + monto.Text);
                            ticket.TextoIzquierda("         CAMBIO........$" + label16.Text);
                            if (groupBox4.Visible == true)
                            {
                                ticket.TextoIzquierda("         MONTO A PAGAR DEBIDO.........$" + textBox1.Text.ToString());
                            }

                            //Texto final del Ticket.

                            ticket.TextoCentro("¡GRACIAS POR SU COMPRA!");
                            ticket.CortaTicket();
                            ticket.ImprimirTicket("Microsoft XPS Document Writer");//Nombre de la impresora ticketera



                        }
                        monto.Clear();
                        textBox2.Clear();
                        textBox4.Clear();
                        codigo.Clear();
                        label16.Text = "0";
                        textBox3.Clear();
                        textBox6.Text = "0";
                        dataGridView1.Rows.Clear();
                        label8.Text = klk.idfact();
                    }
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Se imprimio pero mal");
            }
            


            /*   if (cont != 0)
               {
                   try
                   {
                       string cmd = string.Format("Exec actualizarfactura '{0}'", codigo.Text.Trim());
                       DataSet ds = utilidades.ejecutar(cmd);
                       string numfact = ds.Tables[0].Rows[0][""].ToString().Trim();
                       foreach(DataGridViewRow fila in dataGridView1.Rows)
                       {
                           cmd = string.Format("Exec actualizardetalle '{0}','{1}','{2}','{3}','{4}','{5}','{6}'", numfact, fila.Cells[0].Value.ToString(), fila.Cells[1].Value.ToString(), fila.Cells[2].Value.ToString(), fila.Cells[3].Value.ToString(), fila.Cells[4].Value.ToString(), fila.Cells[5].Value.ToString(), fila.Cells[6].Value.ToString());
                           ds = utilidades.ejecutar(cmd);
                       }
                       cmd = "Exec datosfactura" + numfact;
                       ds = utilidades.ejecutar(cmd);
                       reportefactura jl = new reportefactura();
                       jl.reportViewer1.LocalReport.DataSources[0].Value = ds.Tables[0];
                       jl.ShowDialog();

                   }
                   catch(Exception error)
                   {
                       MessageBox.Show("Error:" + error.Message);
                   }
                   {

                   }
               }
               */
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            pasar1 jj = new pasar1();
            jj.Show();
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_3(object sender, EventArgs e)
        {

            SqlCommand comando = new SqlCommand("Select * from empleados where cod_empleado=@cod", Conexion);
            comando.Parameters.AddWithValue("@cod", textBox4.Text);
            Conexion.Open();
            SqlDataReader leer = comando.ExecuteReader();
            if (leer.Read())
            {
                textBox2.Text = leer["Nombre"].ToString();

            }
            Conexion.Close();


        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            SqlCommand comando = new SqlCommand("Select * from clientes where Cod_cliente=@cod", Conexion);
            comando.Parameters.AddWithValue("@cod", codigo.Text);
            Conexion.Open();
            SqlDataReader leer = comando.ExecuteReader();
            if (leer.Read())
            {
                textBox3.Text = leer["nombre"].ToString();

            }
            Conexion.Close();

        }

        private void button6_Click_2(object sender, EventArgs e)
        {
            SqlCommand comando = new SqlCommand("Select * from Productos where codigo_prod=@cod", Conexion);
            comando.Parameters.AddWithValue("@cod", codigo2.Text);
            Conexion.Open();
            SqlDataReader leer = comando.ExecuteReader();
            if (leer.Read())
            {
                nombreprod.Text = leer["nombre"].ToString();
                precioprod.Text = leer["precio_unit"].ToString();





            }
            Conexion.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void monto_TextChanged(object sender, EventArgs e)
        {
         
        }

        private void monto_KeyPress(object sender, KeyPressEventArgs e)
        {
         
        }

        private void button7_Click_2(object sender, EventArgs e)
        {
            double c = Convert.ToDouble(monto.Text);
            double d = Convert.ToDouble(textBox6.Text);

            double o = c - d;
            label16.Text = o.ToString();
            if (o < 0)
            {
                if (MessageBox.Show("El cliente a superado su presupuesto, ¿desea guardar cuenta por pagar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    groupBox4.Show();

                    textBox1.Text = label16.Text;

                }
                else
                {
                    button8.Enabled = true;
                }

            }
            else
            {

                button8.Enabled = true;
            }
            


        }
    }
}
