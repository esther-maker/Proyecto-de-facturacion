﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class clientesfactura : Form
    {
        public clientesfactura()
        {
            InitializeComponent();
        }
        conexion InstanciaBD = new conexion();

        private void clientesfactura_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = InstanciaBD.Datosclientes2();
            dataGridView2.DataSource = InstanciaBD.contarclientes2();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = InstanciaBD.Datosclientes();
            dataGridView2.DataSource = InstanciaBD.contarclientes();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
