﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class agregarcuentac : Form
    {
        public agregarcuentac()
        {
            InitializeComponent();
        }
        conexion InstanciaBD = new conexion();
     
       bool Editar = false;


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
          /*  if (Editar == false)
            {
                InstanciaBD.insertarcuenta( monto.Text, cod_clit.Text);
                MessageBox.Show("Registro insertado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datoscuenta();

               
            }
            else
            {
                MessageBox.Show("Llene las casillas");
            }*/
        }

        private void agregarcuentac_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = InstanciaBD.Datoscuenta();
        }

        private void button9_Click(object sender, EventArgs e)
        {

          /*  if (Editar == false)
            {
                if ( monto.Text == "" || cod_clit.Text == "")
                {
                    MessageBox.Show("Llene los campos");
                }
                else
                {
                    InstanciaBD.insertarcuenta(monto.Text, cod_clit.Text);
                    MessageBox.Show("Insertado correctamente");
                    dataGridView1.DataSource = InstanciaBD.Datoscuenta();
                }

            }

            else if (Editar == true)
            {
              //  InstanciaBD.actualizarcuenta(monto.Text, cod_clit.Text, nombre.Text);
                MessageBox.Show("Actualizado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datoscuenta();
                Editar = false;
            }
            else
            {
                MessageBox.Show("Usa Toolselection");
            }*/
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                Editar = true;
                nombre.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                fecha.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                monto.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                cod_clit.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
               

            }

            else
            {
                MessageBox.Show("Seleccione una fila para utilizar Toolselection");
            }

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                MessageBox.Show("Registro elminado");
                InstanciaBD.Eliminarcuenta(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                dataGridView1.DataSource = InstanciaBD.Datoscuenta();

            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }


        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea limpiar los campos?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
              
                cod_clit.Clear();
                nombre.Clear();
                monto.Clear();
              
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Editar = true;
            dataGridView1.DataSource = InstanciaBD.Datoscuenta();
           nombre.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            this.Hide();
            cliente gg = new cliente();
           // gg.cuentac.Text = nombre.Text;
            gg.Hide();
            gg.ShowDialog();

        }

        private void nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            clientesssss hg = new clientesssss();
            hg.Show();
        }
    }
    }

