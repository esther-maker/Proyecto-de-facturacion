﻿namespace papeleria2
{
    partial class productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.BD = new papeleria2.BD();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.produto_marca_provBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.produto_marca_provTableAdapter = new papeleria2.BDTableAdapters.produto_marca_provTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.BD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produto_marca_provBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // BD
            // 
            this.BD.DataSetName = "BD";
            this.BD.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "productos";
            reportDataSource1.Value = this.produto_marca_provBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "papeleria2.productos.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(747, 621);
            this.reportViewer1.TabIndex = 0;
            // 
            // produto_marca_provBindingSource
            // 
            this.produto_marca_provBindingSource.DataMember = "produto_marca_prov";
            this.produto_marca_provBindingSource.DataSource = this.BD;
            // 
            // produto_marca_provTableAdapter
            // 
            this.produto_marca_provTableAdapter.ClearBeforeFill = true;
            // 
            // productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::papeleria2.Properties.Resources.e3ddce;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(747, 621);
            this.Controls.Add(this.reportViewer1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "productos";
            this.Text = "Reporte de productos";
            this.Load += new System.EventHandler(this.productos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produto_marca_provBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private BD BD;
        private System.Windows.Forms.BindingSource produto_marca_provBindingSource;
        private BDTableAdapters.produto_marca_provTableAdapter produto_marca_provTableAdapter;
    }
}