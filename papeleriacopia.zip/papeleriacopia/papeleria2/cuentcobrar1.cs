﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
namespace papeleria2
{
    public partial class cuentcobrar1 : Form
    {
  
        public cuentcobrar1()
        {
            InitializeComponent();
        }
       
        private void cuentcobrar1_Load(object sender, EventArgs e)
        {

            this.reportactivoc.RefreshReport();
        }
    }
}
