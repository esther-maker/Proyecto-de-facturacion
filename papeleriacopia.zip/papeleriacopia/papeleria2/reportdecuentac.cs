﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace papeleria2
{
    public partial class reportdecuentac : Form
    {
        private SqlConnection SQL = new SqlConnection("SERVER=DESKTOP-RNRG215\\SQLEXPRESS;DATABASE=papeleria;INTEGRATED SECURITY=TRUE");
        public reportdecuentac()
        {
            InitializeComponent();
        }
        conexion InstanciaBD = new conexion();
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
       

        private void reportdecuentac_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'BD.DataTable1' Puede moverla o quitarla según sea necesario.
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DataTable1TableAdapter.Fill(this.BD.DataTable1, dateTimePicker1.Value, dateTimePicker2.Value);

            this.reportViewer1.RefreshReport();
        }
    }
}
