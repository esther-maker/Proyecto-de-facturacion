﻿namespace papeleria2
{
    partial class facturaesp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(facturaesp));
            this.factura2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.basededatos = new papeleria2.basededatos();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.nombreclit = new System.Windows.Forms.TextBox();
            this.factura2TableAdapter = new papeleria2.basededatosTableAdapters.factura2TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.factura2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basededatos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // factura2BindingSource
            // 
            this.factura2BindingSource.DataMember = "factura2";
            this.factura2BindingSource.DataSource = this.basededatos;
            // 
            // basededatos
            // 
            this.basededatos.DataSetName = "basededatos";
            this.basededatos.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "factura";
            reportDataSource1.Value = this.factura2BindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "papeleria2.facturas.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(-1, 100);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1123, 398);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 27);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(214, 55);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 45;
            this.button1.Text = "Generar";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // nombreclit
            // 
            this.nombreclit.Location = new System.Drawing.Point(94, 57);
            this.nombreclit.Name = "nombreclit";
            this.nombreclit.Size = new System.Drawing.Size(100, 20);
            this.nombreclit.TabIndex = 46;
            // 
            // factura2TableAdapter
            // 
            this.factura2TableAdapter.ClearBeforeFill = true;
            // 
            // facturaesp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1127, 501);
            this.Controls.Add(this.nombreclit);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "facturaesp";
            this.Load += new System.EventHandler(this.facturageneral_Load);
            ((System.ComponentModel.ISupportInitialize)(this.factura2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basededatos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox nombreclit;
        private System.Windows.Forms.BindingSource factura2BindingSource;
        private basededatos basededatos;
        private basededatosTableAdapters.factura2TableAdapter factura2TableAdapter;
    }
}