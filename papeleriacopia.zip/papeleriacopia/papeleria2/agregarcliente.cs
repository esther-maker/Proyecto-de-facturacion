﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class agregarcliente : Form
    {
        public agregarcliente()
        {
            InitializeComponent();
            this.mensaje.SetToolTip(this.button3, "Limpiar campos");
            this.mensaje.SetToolTip(this.button1, "Seleccionar filas");
            this.mensaje.SetToolTip(this.pictureBox2, "Atrás");
        }


        conexion InstanciaBD = new conexion();
        bool editar = false;



        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }









        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }



        private void agregarcliente_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = InstanciaBD.Datosclientes();
           

        }


        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                editar = true;
                textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                Nombre.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                Apellido.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                Edad.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                Telefono.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                Genero.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                Direccion.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }


        }



       

        private void button3_Click(object sender, EventArgs e)
        {

            if (editar == true)
            {
                InstanciaBD.actualizarclientes(Nombre.Text, Apellido.Text, Edad.Text, Telefono.Text, Direccion.Text, Genero.Text.ToString(), dataGridView1.CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Registro actualizado");
                dataGridView1.DataSource = InstanciaBD.Datosclientes();
                editar = true;
                Nombre.Clear();
                Apellido.Clear();
                Edad.Clear();
                Telefono.Clear();
                Direccion.Clear();
            }

            else
            {

                MessageBox.Show("Llene las casillas");
            }

            {
                if (editar == false)
                {
                    InstanciaBD.insertarcliente(Nombre.Text, Apellido.Text, Edad.Text, Telefono.Text, Direccion.Text, Genero.Text);
                    MessageBox.Show("Insertado");
                    dataGridView1.DataSource = InstanciaBD.Datosclientes();
                    editar = false;
                    Nombre.Clear();
                    Apellido.Clear();
                    Edad.Clear();
                    Telefono.Clear();
                    Direccion.Clear();
                }
                else
                {
                    MessageBox.Show("Lene las casillas");
                }


            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

     
        private void Apellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void Telefono_Enter(object sender, EventArgs e)
        {
            if (Telefono.Text == "Teléfono")
                Telefono.Text = "";
        }

        private void Telefono_Leave(object sender, EventArgs e)
        {
            if (Telefono.Text == "")
                Telefono.Text = "Teléfono";
        }

        private void Direccion_Enter(object sender, EventArgs e)
        {
            if (Direccion.Text == "Dirección")
                Direccion.Text = "";
        }

        private void Direccion_Leave(object sender, EventArgs e)
        {
            if (Direccion.Text == "")
                Direccion.Text = "Dirección";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                editar = true;
                textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                Nombre.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                Apellido.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                Edad.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                Telefono.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                Genero.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                Direccion.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            }

            else
            {
                MessageBox.Show("Seleccione una fila para utilizar tollselection");
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                InstanciaBD.Eliminarclientes(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Registro eliminado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datosclientes();

            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
             if (editar == false)
            {
            if (Nombre.Text == "" || Apellido.Text == "" || Edad.Text == "" || Telefono.Text == "" || Direccion.Text == "" )
             {
              MessageBox.Show("Llene los campos");
            }
            else
            {
            InstanciaBD.insertarcliente(Nombre.Text, Apellido.Text,Edad.Text,Telefono.Text, Direccion.Text, Genero.SelectedItem.ToString());
              MessageBox.Show("Insertado correctamente");
             dataGridView1.DataSource = InstanciaBD.Datosclientes();
            }

            }

            else if (editar == true)
            {
                InstanciaBD.actualizarclientes(Nombre.Text, Apellido.Text, Edad.Text, Telefono.Text, Direccion.Text, Genero.SelectedValue.ToString(), textBox1.Text );
                MessageBox.Show("Actualizado correctamente");
                dataGridView1.DataSource = InstanciaBD.Datosclientes();
                editar = false;
                }
                else
                 {
              MessageBox.Show("Usa Toolselection");
                 }
            }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            deshabilitarcliente oo = new deshabilitarcliente();
            oo.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void Nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("Ingresaste un número!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }

        private void Apellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("Ingresaste un número!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }

        private void Direccion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("Ingresaste un número!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }

        private void Edad_TextChanged(object sender, EventArgs e)
        {

        }

        private void Edad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Ingresaste una letra!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }

        private void Direccion_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("Ingresaste un número!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;

            }
        }
    }

      

     
        }

     
    


    
