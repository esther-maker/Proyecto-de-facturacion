﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class after2login : Form
    {
        public after2login(string NOMBRE)
        {
            InitializeComponent();
            label2.Text = "Bienvenido/a"+ ":"+"  " + NOMBRE;
        }

        private void after2login_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            principal gg = new principal();
            gg.Show();
            this.Close();
        }
    }
}
