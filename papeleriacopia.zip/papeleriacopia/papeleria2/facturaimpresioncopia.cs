﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace papeleria2
{
    public partial class facturaimpresioncopia : Form
    {
        public facturaimpresioncopia()
        {
            InitializeComponent();

            conexion con = new conexion();
            textBox3.Text = con.idcop();

            
        }

        bool Editar = false;

        conexion klk = new conexion();

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void ListarModos()
        {
            comboBox1.DataSource = klk.ListarModos();
            comboBox1.DisplayMember = "modo";
            comboBox1.ValueMember = "id_modo";
           
        }


        private void impresioncopia_Load(object sender, EventArgs e)
        {
            factura.DataSource = klk.Datoscopia();
            ListarModos();

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void preciocopia_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double c = Convert.ToDouble(monto.Text);
            double d = Convert.ToDouble(total.Text);

            double o = c - d;
            dev.Text = o.ToString();
            if (o <= -0)
            {
                if (MessageBox.Show("El cliente a superado su presupuesto, ¿desea guardar cuenta por pagar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    agregarcuentac kk = new agregarcuentac();
                    kk.Show();
                }


            }
        }
        private void dev_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Editar == false)
            {
                klk.insertarcopia(comboBox1.SelectedValue.ToString(), cantidad.Text, precio.Text, total.Text, monto.Text, dev.Text, textBox3.Text);
                MessageBox.Show("Registro guardado correctamente");
                factura.DataSource = klk.Datoscopia();

            }
            else
            {
                MessageBox.Show("Llene las casillas");
            }


    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = Convert.ToString(comboBox1.Text);

            if (a == "blanco/negro")
            {
                precio.Text = "5";
            }
            else if (a == "color")
            {
                precio.Text = "10";
            }
            else
            {
                precio.Text = "eta mielda no sirve";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            agregarcliente kk = new agregarcliente();
            kk.Show();
        }

        private void cliente_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (factura.SelectedRows.Count > 0)
            {
                klk.Eliminarcopia(factura.CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Registro eliminado correctamente");

            }

            else
            {
                MessageBox.Show("Seleccione una fila");
            }
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(cantidad.Text);
            double b = Convert.ToDouble(precio.Text);

            double r = a * b;
            total.Text = r.ToString();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void factura2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {



        }

        private void button9_Click(object sender, EventArgs e)
        { 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            facturaimpresioncopia hf = new facturaimpresioncopia();
            hf.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
